import functions_framework
from flask import jsonify


@functions_framework.http
def pwd_reset(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
        <https://flask.palletsprojects.com/en/1.1.x/api/#incoming-request-data>
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
        <https://flask.palletsprojects.com/en/1.1.x/api/#flask.make_response>.
    """
    request_json = request.get_json(silent=True)

    ## Retrieve the input parameters
    #
    first_name = request_json['sessionInfo']['parameters']['first_name']
    middle_name = request_json['sessionInfo']['parameters']['middle_name']
    last_name = request_json['sessionInfo']['parameters']['last_name']
    last_4_ssn = request_json['sessionInfo']['parameters']['last_4_ssn']
    billing_zip_code = request_json['sessionInfo']['parameters']['billing_zip_code']

    #
    # Access the back-end system to verify the user, get info needed to reset the pwd
    #
    # Execute actions needed
    #
    #
    
    #
    # Submit SMS notification for pwd reset
    #

    text = "pwd reset successfully"   
    # Format for Dialogflow
    response = {
        "fulfillmentResponse": {
            "messages": [{"text": {"text": [text or "No information found."]}}]
        }    
    }

    print(response)
    
    return jsonify(response)
